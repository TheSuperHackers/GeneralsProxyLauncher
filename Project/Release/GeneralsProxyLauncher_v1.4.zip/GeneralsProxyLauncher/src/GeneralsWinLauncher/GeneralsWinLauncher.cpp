
#include "stdafx.h"

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

// The command line parameters you use, e.g. -win -quickstart
// Note: This application also passes through other parameters
// which are issued to this executable
#define COMMANDLINE L" -win"

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

void Copyd3d8(std::wstring generalsDir, std::wstring launcherDir)
{
	wchar_t* gentool = L"\\d3d8.dll";
	generalsDir.append(gentool);
	launcherDir.append(gentool);

	if(CopyFileW(generalsDir.c_str(), launcherDir.c_str(), FALSE) == FALSE) {
		DeleteFileW(launcherDir.c_str());
	}
}

//////////////////////////////////////////////////////////////

int _tmain(int argc, _TCHAR* argv[])
{
	printf("Generals Proxy Launcher v1.4 by xezon\n");
	printf("-------------------------------------\n");

	wchar_t generalsDir[MAX_PATH] = {0};
	wchar_t launcherDir[MAX_PATH] = {0};
	GetModuleFileNameW(NULL, launcherDir, MAX_PATH);
	PathRemoveFileSpecW(launcherDir);
	wcscpy_s(generalsDir, MAX_PATH, launcherDir);
	PathRemoveFileSpecW(generalsDir);

	//Copyd3d8(generalsDir, launcherDir);

	wchar_t applicationExe[MAX_PATH] = {0};
	wchar_t commandlineTxt[MAX_PATH] = {0};
	wcscpy_s(commandlineTxt, MAX_PATH, launcherDir);
	wcscat_s(commandlineTxt, MAX_PATH, L"\\commandline.txt");
	wcscpy_s(applicationExe, MAX_PATH, generalsDir);
	wcscat_s(applicationExe, MAX_PATH, L"\\generals.exe");

	const size_t sz = 2048;
	wchar_t commandline[sz] = {0};
	FILE* fp;

	if(_wfopen_s(&fp, commandlineTxt, L"r")==0)
	{
		char commandline_mb[sz] = {0};
		fseek(fp, 0, SEEK_END);
		long fs = ftell(fp);
		fseek(fp, 0, SEEK_SET);
		if(fread(commandline_mb, sizeof(char), fs>sz?sz:fs, fp)!=0)
		{
			mbstowcs(commandline, commandline_mb, sz);
		}
		fclose(fp);
	}
	else
	{
		wcscpy_s(commandline, sz, COMMANDLINE);
	}
	for(int i=1; i<argc; i++)
	{
		wcscat_s(commandline, sz, L" ");
		wcscat_s(commandline, sz, argv[i]);
	}
	STARTUPINFO si = {0};
    PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si);

	wprintf(L"Launching %s%s\n", applicationExe, commandline);

    if(!CreateProcessW(
		applicationExe, // No module name (use command line)
        commandline,    // Command line
        NULL,           // Process handle not inheritable
        NULL,           // Thread handle not inheritable
        FALSE,          // Set handle inheritance to FALSE
        0,              // No creation flags
        NULL,           // Use parent's environment block
        generalsDir,    // Use parent's starting directory 
        &si,            // Pointer to STARTUPINFO structure
        &pi )           // Pointer to PROCESS_INFORMATION structure
    )
    {
        printf("Game launch failed (%d)\n\n", GetLastError());
		printf("Press ENTER to shutdown...\n");
		getchar();
        return 0;
    }
	else
	{
		printf("Game launch successful\nDo not close this box. Please wait...\n");
	}

    WaitForSingleObject(pi.hProcess, INFINITE);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
	return 0;
}
