-------------------------------------------------------------------------------
--- Generals Proxy Launcher for GENERALS & GENERALS: ZERO HOUR ----------------
-------------------------------------------------------------------------------

This tool allows to run generals.exe
with command line arguments through GameRanger.

-------------------------------------------------------------------------------
--- Install -------------------------------------------------------------------
-------------------------------------------------------------------------------

1. Copy the "launcher" folder and its belonging content
   into the game install directory
     for example
     C:\Program Files (x86)\EA Games\Command & Conquer Generals Zero Hour
     (DO NOT replace the original generals.exe from your game install)

2. Start GameRanger

3. Open Edit > Options > Games

4. Select the game you use from the list

5. Click Browse... and navigate to \launcher\generals.exe


-------------------------------------------------------------------------------
--- Changelog -----------------------------------------------------------------
-------------------------------------------------------------------------------

v1.1:
- Added commandline.txt to specify custom parameters along " -win"
  Credits to Stubbjax for fine idea

v1.2
- Added proper MapsZH.big file format to avoid trouble in generals file parser

v1.3
- Changed project and strings to Unicode (commandline.txt remains ansi)
- Now transfers correct default working directory to spawning generals.exe
- Fixed Error 740: Added UAC Execution Level "highestAvailable"
- Copies d3d8.dll from root to launcher directory for possible needs in future

v1.4
- Reverted d3d8.dll copying

v1.5
- Changed CreateProcess to ShellExecute