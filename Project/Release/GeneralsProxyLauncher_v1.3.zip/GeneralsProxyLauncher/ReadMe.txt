Generals Proxy Launcher for GENERALS & GENERALS: ZERO HOUR

-------------------------------------------------------------------------------
--- Author --------------------------------------------------------------------

xezon


-------------------------------------------------------------------------------
--- Install -------------------------------------------------------------------

1. Copy the "launcher" folder and its content into the game install directory
   sample C:\Program Files (x86)\EA Games\Command & Conquer Generals Zero Hour
2. Start GameRanger
3. Open Edit > Options > Games
4. Select the game you use from the list
5. Click Browse... and navigate to \launcher\generals.exe


-------------------------------------------------------------------------------
--- UAC Treatment -------------------------------------------------------------

You should Run GameRanger As Adminstrator, otherwise the launcher will ask for
administrator privileges on every game start


-------------------------------------------------------------------------------
--- Changelist ----------------------------------------------------------------

v1.1:
- Added commandline.txt to specify custom parameters along " -win"
  Credits to Stubbjax for fine idea

v1.2
- Added proper MapsZH.big file format to avoid trouble in generals file parser

v1.3
- Changed project and strings to Unicode (commandline.txt remains ansi)
- Now transfers correct default working directory to spawning generals.exe
- Error 740: Added UAC Execution Level "highestAvailable"
- Copies d3d8.dll from root to launcher directory for possible needs in future


-------------------------------------------------------------------------------
--- Remarks -------------------------------------------------------------------

For personal use only.
Do not redistibute on public platform.