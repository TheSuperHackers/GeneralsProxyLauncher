// GeneralsWinLauncher.cpp : Defines the entry point for the console application.
#include "stdafx.h"

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

// EDIT THESE 2 LINES IF NECESSARY:

// The game application path
#define APPLICATION "..\\generals.exe"

// The command line parameters you use, e.g. -win -quickstart
// Note: This application also passes through other parameters
// which are issued to this executable
#define COMMANDLINE " -win"

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

int _tmain(int argc, _TCHAR* argv[])
{
	printf("Generals Proxy Launcher v1.2 by xezon\n");
	printf("-------------------------------------\n");

	wchar_t filename[MAX_PATH];
	GetModuleFileNameW(NULL, filename, MAX_PATH);
	PathRemoveFileSpecW(filename);
	wcscat_s(filename, MAX_PATH, L"\\commandline.txt");

	const int sz = 2048;
	char commandline[sz] = {0};
	FILE* fp;

	if(_wfopen_s(&fp, filename, L"r")==0)
	{
		fseek(fp, 0, SEEK_END);
		long fs = ftell(fp);
		fseek(fp, 0, SEEK_SET);
		fread(commandline, 1, fs>sz?sz:fs, fp);
		fclose(fp);
	}
	else
	{
		strcpy_s(commandline, sz, COMMANDLINE);
	}
	for(int i=1; i<argc; i++)
	{
		strcat_s(commandline, sz, " ");
		strcat_s(commandline, sz, argv[i]);
	}
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

	printf("Launching %s%s\n", APPLICATION, commandline);

    if(!CreateProcess(
		APPLICATION,    // No module name (use command line)
        commandline,    // Command line
        NULL,           // Process handle not inheritable
        NULL,           // Thread handle not inheritable
        FALSE,          // Set handle inheritance to FALSE
        0,              // No creation flags
        NULL,           // Use parent's environment block
        NULL,           // Use parent's starting directory 
        &si,            // Pointer to STARTUPINFO structure
        &pi )           // Pointer to PROCESS_INFORMATION structure
    )
    {
        printf("Game launch failed (%d)\n\n", GetLastError());
		printf("Press ENTER to shutdown...\n");
		getchar();
        return 0;
    }
	else
	{
		printf("Game launch successful\nDo not close this box. Please wait...\n");
	}

    WaitForSingleObject(pi.hProcess, INFINITE);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
	return 0;
}
