Generals Proxy Launcher for GENERALS & GENERALS: ZERO HOUR

Author:
xezon

Install:
1. Copy the "launcher" folder and its content into the game install directory (e.g. C:\Program Files (x86)\EA Games\Command & Conquer Generals Zero Hour)
2. Start GameRanger
3. Open Edit > Options > Games
4. Select the game you use from the list
5. Click Browse... and navigate to \launcher\generals.exe

Remarks:
For personal use only.
Do not redistibute on public platform.

v1.1:
Added commandline.txt to specify custom parameters along " -win". Credits to Stubbjax for fine idea.

v1.2
Added proper MapsZH.big file format to avoid trouble in generals file parser