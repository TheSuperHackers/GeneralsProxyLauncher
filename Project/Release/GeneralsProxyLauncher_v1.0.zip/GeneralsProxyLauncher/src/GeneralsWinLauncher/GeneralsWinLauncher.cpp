// GeneralsWinLauncher.cpp : Defines the entry point for the console application.
#include "stdafx.h"

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

// EDIT THESE 2 LINES IF NECESSARY:

// The game application path
#define APPLICATION L"..\\generals.exe"

// The command line parameters you use, e.g. -win -quickstart
// Note: This application also passes through other parameters
// which are issued to this executable
#define COMMANDLINE L" -win"

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

int _tmain(int argc, _TCHAR* argv[])
{
	wprintf(L"Generals Proxy Launcher v1.0 by xezon\n");
	wprintf(L"-------------------------------------\n");

	// Use original command line + win
	TCHAR commandline[2048];
	wcscpy(commandline, COMMANDLINE);
	for(int i=1; i<argc; i++)
	{
		wcscat(commandline, L" ");
		wcscat(commandline, argv[i]);
	}

    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    // Start the child process. 
    if(!CreateProcess(
		APPLICATION,    // No module name (use command line)
        commandline,    // Command line
        NULL,           // Process handle not inheritable
        NULL,           // Thread handle not inheritable
        FALSE,          // Set handle inheritance to FALSE
        0,              // No creation flags
        NULL,           // Use parent's environment block
        NULL,           // Use parent's starting directory 
        &si,            // Pointer to STARTUPINFO structure
        &pi )           // Pointer to PROCESS_INFORMATION structure
    )
    {
        wprintf(L"Game launch failed (%d)\n", GetLastError());
		wprintf(L"Make sure this executable will find the original generals.exe at %s\n\n", APPLICATION);
		wprintf(L"Press ENTER to shutdown...\n");
		getchar();
        return 0;
    }
	else
	{
		wprintf(L"Game launch initiated\nDo not close this box. Please wait...\n");
	}

    // Wait until child process exits
    WaitForSingleObject(pi.hProcess, INFINITE);

    // Close process and thread handles
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
	return 0;
}
